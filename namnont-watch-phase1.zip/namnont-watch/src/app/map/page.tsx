import type { Metadata } from "next";
import { Map as MapIcon } from "lucide-react";
import { EmptyState } from "@/components/ui/EmptyState";
import { SectionTitle } from "@/components/ui/SectionTitle";
import { ButtonLink } from "@/components/ui/ButtonLink";

export const metadata: Metadata = { title: "แผนที่" };

// หน้านี้ยังไม่เปิดใช้งาน — จะทำในเฟส 5
export default function Page() {
  return (
    <>
      <SectionTitle as="h1">แผนที่</SectionTitle>
      <EmptyState
        icon={MapIcon}
        title="ยังไม่เปิดใช้งาน"
        description="จะแสดงแผนที่จุดอพยพและสถานีวัดน้ำ ในเฟส 5 (ยังไม่มีข้อมูลจุดอพยพที่ตรวจสอบแล้ว)"
        action={<ButtonLink href="/prepare" variant="outline">ดูวิธีเตรียมตัวระหว่างนี้</ButtonLink>}
      />
    </>
  );
}
