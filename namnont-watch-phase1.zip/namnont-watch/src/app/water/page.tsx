import type { Metadata } from "next";
import { Waves } from "lucide-react";
import { EmptyState } from "@/components/ui/EmptyState";
import { SectionTitle } from "@/components/ui/SectionTitle";
import { ButtonLink } from "@/components/ui/ButtonLink";

export const metadata: Metadata = { title: "ระดับน้ำ" };

// หน้านี้ยังไม่เปิดใช้งาน — จะทำในเฟส 3
export default function Page() {
  return (
    <>
      <SectionTitle as="h1">ระดับน้ำ</SectionTitle>
      <EmptyState
        icon={Waves}
        title="ยังไม่เปิดใช้งาน"
        description="จะแสดงระดับน้ำและการระบายน้ำเขื่อน เมื่อเชื่อมข้อมูลในเฟส 3"
        action={<ButtonLink href="/prepare" variant="outline">ดูวิธีเตรียมตัวระหว่างนี้</ButtonLink>}
      />
    </>
  );
}
