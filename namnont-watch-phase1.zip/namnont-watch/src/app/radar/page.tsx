import type { Metadata } from "next";
import { Radar } from "lucide-react";
import { EmptyState } from "@/components/ui/EmptyState";
import { SectionTitle } from "@/components/ui/SectionTitle";
import { ButtonLink } from "@/components/ui/ButtonLink";

export const metadata: Metadata = { title: "เรดาร์ฝน" };

// หน้านี้ยังไม่เปิดใช้งาน — จะทำในเฟส 4
export default function Page() {
  return (
    <>
      <SectionTitle as="h1">เรดาร์ฝน</SectionTitle>
      <EmptyState
        icon={Radar}
        title="ยังไม่เปิดใช้งาน"
        description="จะแสดงเรดาร์และพยากรณ์ฝน เมื่อเชื่อมข้อมูลในเฟส 4"
        action={<ButtonLink href="/prepare" variant="outline">ดูวิธีเตรียมตัวระหว่างนี้</ButtonLink>}
      />
    </>
  );
}
