import Link from "next/link";
import { ClipboardCheck, LifeBuoy } from "lucide-react";
import { DataCard } from "@/components/ui/DataCard";
import { SectionTitle } from "@/components/ui/SectionTitle";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { LEVEL_ORDER } from "@/lib/situation";

// หน้าภาพรวม (เฟส 1: ยังไม่เชื่อมข้อมูลจริง)
// การ์ดด้านล่างจึงแสดง "ยังไม่มีข้อมูล" — ห้ามใส่ตัวเลขสมมติ
export default function HomePage() {
  return (
    <div className="space-y-8">
      <section>
        <SectionTitle as="h1" description="ระดับน้ำ เขื่อน ฝน และสิ่งที่ควรทำ ในที่เดียว">
          ภาพรวมสถานการณ์
        </SectionTitle>
        <div className="space-y-3">
          {/* TODO เฟส 3: เชื่อมข้อมูลระดับน้ำเจ้าพระยาจริง */}
          <DataCard title="ระดับน้ำเจ้าพระยา (นนทบุรี)" />
          {/* TODO เฟส 3: เชื่อมข้อมูลการระบายน้ำเขื่อน */}
          <DataCard title="การระบายน้ำเขื่อนเจ้าพระยา" />
        </div>
      </section>

      <section>
        <SectionTitle description="ทุกระดับมีไอคอนและข้อความกำกับ ไม่ได้ใช้สีอย่างเดียว">
          ระดับสถานการณ์
        </SectionTitle>
        <ul className="flex flex-wrap gap-2">
          {LEVEL_ORDER.map((lv) => (
            <li key={lv}>
              <StatusBadge kind="level" value={lv} size="lg" />
            </li>
          ))}
        </ul>
      </section>

      <section>
        <SectionTitle>ทำอะไรได้ตอนนี้</SectionTitle>
        <div className="grid gap-3">
          <Link
            href="/prepare"
            className="flex min-h-16 items-center gap-3 rounded-card border border-line bg-surface p-4"
          >
            <ClipboardCheck className="h-8 w-8 shrink-0 text-brand" aria-hidden />
            <span>
              <span className="block text-lg font-semibold">เตรียมตัวรับน้ำท่วม</span>
              <span className="block text-base text-ink-muted">เช็กลิสต์ก่อน ระหว่าง และหลังน้ำท่วม</span>
            </span>
          </Link>
          <Link
            href="/help"
            className="flex min-h-16 items-center gap-3 rounded-card border border-line bg-surface p-4"
          >
            <LifeBuoy className="h-8 w-8 shrink-0 text-brand" aria-hidden />
            <span>
              <span className="block text-lg font-semibold">ขอความช่วยเหลือ</span>
              <span className="block text-base text-ink-muted">เบอร์ฉุกเฉิน และส่งตำแหน่งของคุณ</span>
            </span>
          </Link>
        </div>
      </section>
    </div>
  );
}
