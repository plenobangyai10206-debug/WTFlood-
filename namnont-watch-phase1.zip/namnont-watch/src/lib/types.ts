// ชนิดข้อมูลกลางที่ทั้งเว็บใช้ร่วมกัน
// (adapter ในเฟส 3–4 จะแปลงข้อมูลจากแต่ละแหล่งให้เป็นชนิดเหล่านี้)

/** ระดับสถานการณ์ 4 ระดับ: ปกติ / เฝ้าระวัง / เตือนภัย / วิกฤต */
export type SituationLevel = "ok" | "watch" | "warning" | "critical";

/** ความสดของข้อมูล: สด / ค้าง (ใช้ข้อมูลแคชเก่า) / ไม่พร้อมใช้งาน */
export type Freshness = "live" | "stale" | "unavailable";

/** แหล่งที่มาของข้อมูล */
export interface SourceRef {
  name: string;
  url?: string;
}
